//Chris Guilford
import java.util.Scanner;
import java.security.*;
public class ranArray {

	public static void main(String[] args) {
		int userNum;
		final int NUM = 10;

		Scanner input = new Scanner(System.in);
		SecureRandom ranNumber = new SecureRandom();
		System.out.println("Enter a number greater than 0 and less than 100");
		userNum = input.nextInt();
		
		int[] numArray = new int[NUM];
				
		for (int i = 0; i < numArray.length; i++){
			 numArray[i] = 1 + ranNumber.nextInt(100);
			}// End of For	    
		while (userNum <= 0 || userNum >= 100){
			System.out.println("Incorrect entry! Please enter a number greater than 0 and less than 100" );
		userNum = input.nextInt();
		}
		displayGreaterThan(numArray, userNum);
	}//End of Main
public static void displayGreaterThan(int numArray[], int userNum){
	for (int i : numArray){
		if (i > userNum){
		System.out.println(i);
		}//End of if
	}//End of For		
}//End of Method
}//End of class
